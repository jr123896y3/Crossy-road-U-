Blur Racing

This game can be either self hosted or embedded on your site.

TO SELF HOST: unpack the blurraching.zip file.

TO EMBED:

<iframe src='https://bubblebox.com/html5/embed/blurracing/' width='800' height='600' frameborder='0' scrolling='no' marginwidth='0' marginheight='0'></iframe>

===========
Blur Racing

Developed by Max Karev

Description:
A futuristic 3D arcade racer. Test your driving skills against AI bots on high speed neon tracks. Avoid obstacles and collect power ups, beat your opponents and try to top the high scores table!

Instructions:
Use the ARROW Keys or [A] & [D] to steer.<br/>
Collect power ups and meet the race mission conditions the proceed to the next race.<br/>
Power ups are: increase time, health, shield, decrease rival speed.<br/>
Avoid these: damage, decrease time, decrease speed and increase opposition speed. 
